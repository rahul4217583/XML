﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
  class TableControls : Control
    {
        TextBox PKID;
        //OHR attributes
        ComboBox FRM_FACTOR_CL1, FRM_FACTOR_CL2, TOUCH_SCREEN;
        TextBox SCREEN_SIZE, PC_MODEL_SKU;
        //Optional info attributes
        TextBox ZOEM_EXT_ID, ZCHANNEL_REL_ID, ZMANUF_GEO_LOC, ZPGM_ELIG_VAL, ZSELLIN_LOC;

        public TableControls()
        {
            PKID = new TextBox();
            //OHR attributes
            FRM_FACTOR_CL1 = new ComboBox();
            FRM_FACTOR_CL2 = new ComboBox();
            TOUCH_SCREEN = new ComboBox();
            SCREEN_SIZE = new TextBox();
            PC_MODEL_SKU = new TextBox();

            //Optional info attributes
            ZOEM_EXT_ID = new TextBox();
            ZCHANNEL_REL_ID = new TextBox();
            ZMANUF_GEO_LOC = new TextBox();
            ZPGM_ELIG_VAL = new TextBox();
            ZSELLIN_LOC = new TextBox();

            // FRM_FACTOR_CL1 values addition
            FRM_FACTOR_CL1.Items.Add(" ");
            FRM_FACTOR_CL1.Items.Add("Desktop");
            FRM_FACTOR_CL1.Items.Add("Notebook");
            FRM_FACTOR_CL1.Items.Add("Tablet");
            FRM_FACTOR_CL1.SelectedIndex = 0;

            // FRM_FACTOR_CL2 values addition
            FRM_FACTOR_CL2.Items.Add(" ");
            FRM_FACTOR_CL2.Items.Add("Standard");
            FRM_FACTOR_CL2.Items.Add("AIO");
            FRM_FACTOR_CL2.Items.Add("Convertible");
            FRM_FACTOR_CL2.Items.Add("Ultraslim");
            FRM_FACTOR_CL2.SelectedIndex = 0;

            //TOUCH_SCREEN  values addition
            TOUCH_SCREEN.Items.Add(" ");
            TOUCH_SCREEN.Items.Add("Touch");
            TOUCH_SCREEN.Items.Add("Non-Touch");
            TOUCH_SCREEN.SelectedIndex = 0;
        }
  
    }

    
}
