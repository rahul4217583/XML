﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml;
using System.Collections;

namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        
        private String[] attributes;
        ArrayList controlList;


        public Form1()
        {
           
            InitializeComponent();
          

        }

       


        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void submit_Click(object sender, EventArgs e)
        {
            Int32 column, row;
            column = 0;
            row = tableLayoutPanel1.RowCount;
            row++;

         

            XmlTextWriter writer = new XmlTextWriter("product.xml", System.Text.Encoding.UTF8);
            writer.WriteStartDocument(true);
            writer.Formatting = Formatting.Indented;
            writer.Indentation = 2;
            writer.WriteStartElement("Binding");
            getValues();
            switch (column)
            {
                case 0:
                    writer.WriteElementString("ProductKeyID", attributes[1]);
                    break;


            }
            writer.WriteEndElement();         
           
            writer.Close();
            MessageBox.Show("XML File created ! ");
        



    }

        private void label15_Click(object sender, EventArgs e)
        {

        }

        public void getValues()
        {
            attributes = new string[26];
            for (int i = 0;i<4;i++)
            {
                attributes[i]= tableLayoutPanel1.GetControlFromPosition(i, 1).Text;

                
            }
            Console.Write("hifhftjrtjrtjtj");
            Console.Write(attributes[1]);
            if (attributes[1] == " ")
            {
                Console.Write("hi bye");
            }
        }

    private void RowCount_KeyUp(object sender, KeyEventArgs e)
        {
            
        }       



        private void RowCount_DoubleClick(object sender, EventArgs e)
        {
         
            int y = Int32.Parse(RowCount.Text);
            Console.WriteLine(y);

            controlList = new ArrayList();

            controlList.Add(new TableControls());

            foreach (object o in controlList)
            {
                String type = o.GetType().ToString();
                Console.Write(type);
              //  tableLayoutPanel1.Controls.Add(null, 0, 1);
                
            }

         /*   //Addind objects to tableLayoutPanel1
            tableLayoutPanel1.Controls.Add(null, 0, 1);
            tableLayoutPanel1.Controls.Add(FRM_FACTOR_CL1, 1, 1);
            tableLayoutPanel1.Controls.Add(FRM_FACTOR_CL2, 2, 1);
            tableLayoutPanel1.Controls.Add(TOUCH_SCREEN, 3, 1);
            tableLayoutPanel1.Controls.Add(SCREEN_SIZE, 4, 1);
            tableLayoutPanel1.Controls.Add(PC_MODEL_SKU, 5, 1);
            */
             
        }
    }
}
